DP-30 raw tool evidence. NOT application capacity or deployment evidence.
probe-suite-final is the final tool revision, three repetitions of six fixture cases.
probe-suite-01 is an earlier development revision; do not pool its metrics with the final revision.
validator-cases* contain SYNTHETIC input records and observed verifier output.
Each synthetic release timing and resource value is a test constant, not a measurement.
All available earlier runs are retained rather than selecting the best run.
